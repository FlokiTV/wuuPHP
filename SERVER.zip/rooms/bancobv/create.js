module.exports = (room, options) => {
    room.setMetadata({ name: options.name })
    room.state.inventory.push(new room.Game.state.Inventory())
    room.name = options.name
    /* Reconnect */ 
    room.missionListTEMP  = []
    room.dragConnEvents   = []

    /* Codes */ 
    room.missionList = [{
      code: 5391,
      scene:'',
      events:[
        [ "modal.close", "email1" ],
        [ "modal.close", "prancheta" ],
        [ "hotspot.remove", { id:"tv", selector: false } ],
        [ "hotspot.remove", { id:"pc", selector: false } ],
        [ "dica.change", 2 ],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./front/scenes/01/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email2")
          return pc
        }],
        [ "hotspot.add", require('./front/scenes/01/hotspots/mapa') ]
        // [ "modal.open", "re_email1" ]
      ],
      fn:(client, cfg) => {
        room.broadcast("modal.close", "email1")
        room.broadcast("modal.close", "prancheta")
        room.broadcast("hotspot.remove", {id:"tv", selector: false })
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("dica.change", 2)
        let pc = { ...require('./front/scenes/01/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email2")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./front/scenes/01/hotspots/mapa'))
        // room.broadcast("modal.open", "re_email1")
      }
    },
    {
      code: 8627,
      scene:'',
      events:[
        [ "modal.close", "email2" ],
        [ "modal.close", "mapa" ],
        [ "hotspot.remove", {id:"pc", selector: false } ],
        [ "hotspot.remove", { id:"mapa", selector: false } ],
        [ "dica.change", 3 ],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./front/scenes/01/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email3")
          return pc
        }],
        [ "hotspot.add", require('./front/scenes/01/hotspots/funcionario') ],
        [ "hotspot.add", require('./front/scenes/01/hotspots/cliente') ],
        // [ "modal.open", "re_email2" ]
      ],
      fn:(client, cfg) => {
        room.broadcast("modal.close", "email2")
        room.broadcast("modal.close", "mapa")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"mapa", selector: false })
        room.broadcast("dica.change", 3)
        let pc = { ...require('./front/scenes/01/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email3")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./front/scenes/01/hotspots/funcionario'))
        room.broadcast("hotspot.add", require('./front/scenes/01/hotspots/cliente'))
        // room.broadcast("modal.open", "re_email2")
      }
    },
    {
      code:5217,
      scene:'',
      events:[
        [ "modal.close", "email3" ],
        [ "modal.close", "cliente" ],
        [ "modal.close", "celular" ],
        [ "hotspot.remove", {id:"pc", selector: false } ],
        [ "hotspot.remove", { id:"cliente", selector: false } ],
        [ "hotspot.remove", { id:"funcionario", selector: false } ],
        [ "dica.change", 4 ],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./front/scenes/01/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email4")
          return pc
        }],
        [ "hotspot.add", require('./front/scenes/01/hotspots/nota') ],
        // [ "modal.open", "re_email2" ]
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email3")
        room.broadcast("modal.close", "cliente")
        room.broadcast("modal.close", "celular")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"cliente", selector: false })
        room.broadcast("hotspot.remove", {id:"funcionario", selector: false })
        room.broadcast("dica.change", 4)
        let pc = { ...require('./front/scenes/01/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email4")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./front/scenes/01/hotspots/nota'))

      }
    },
    {
      code:'empatia',
      scene:'',
      events:[
        ["modal.close", "email4"],
        ["modal.close", "nota"],
        ["hotspot.remove", {id:"pc", selector: false }],
        ["hotspot.remove", {id:"nota", selector: false }],
        ["dica.change", 5],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./front/scenes/01/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email5")
          return pc
        }],
        [ "hotspot.add", require('./front/scenes/01/hotspots/tv2') ],
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email4")
        room.broadcast("modal.close", "nota")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"nota", selector: false })
        room.broadcast("dica.change", 5)
        let pc = { ...require('./front/scenes/01/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email5")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./front/scenes/01/hotspots/tv2'))
      }
    },
    {
      code:'7245',
      scene:'',
      events:[
        // ["scene.change", "02"],
        ["modal.close", "email5"],
        ["modal.close", "inicial"],
        ["hotspot.remove", {id:"pc", selector: false }],
        ["hotspot.remove", {id:"tv", selector: false }],
        ["dica.change", 6],
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email5")
        room.broadcast("modal.close", "inicial")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"tv", selector: false })
        // room.broadcast("scene.change", "02")
        room.setScene("02")
        room.broadcast("dica.change", 6)
      }
    },
    {
      code:'circuito',
      scene:'',
      events:[
        ["modal.close", "circuito"],
        ["modal.close", "servidor"],
        ["modal.close", "email6"],
        ["hotspot.remove", {id:"pc", selector: false }],
        ["hotspot.remove", {id:"tv", selector: false }],
        ["hotspot.remove", {id:"ti", selector: false }],
        ["dica.change", 7],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./front/scenes/02/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email6","email7")
          return pc
        }],
        ["hotspot.add", require('./front/scenes/02/hotspots/mesa')],
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "circuito")
        room.broadcast("modal.close", "servidor")
        room.broadcast("modal.close", "email6")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"tv", selector: false })
        room.broadcast("hotspot.remove", {id:"ti", selector: false })
        room.broadcast("dica.change", 7)
        let pc = { ...require('./front/scenes/02/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email6","email7")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./front/scenes/02/hotspots/mesa'))
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code: 869218471,
      scene: '',
      events:[
        ["modal.close", "mesa"],
        ["modal.close", "email7"],
        ["hotspot.remove", {id:"pc", selector: false }],
        ["hotspot.remove", {id:"mesa", selector: false }],
        ["dica.change", 8],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./front/scenes/02/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email6","mesa_site")
          return pc
        }],
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "mesa")
        room.broadcast("modal.close", "email7")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"mesa", selector: false })
        room.broadcast("dica.change", 8)
        let pc = { ...require('./front/scenes/02/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email6","mesa_site")
        room.broadcast("hotspot.add", pc)
        room.broadcast("modal.open",  "mesa_site")
        room.broadcast("modal.open",  "email8")
      }
    },
    {
      code:'site',
      scene:'',
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_site")
        room.broadcast("modal.close", "email8")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("dica.change", 9)
        room.setScene("03")
        // room.broadcast("hotspot.add", require('./front/scenes/02/hotspots/pc1'))
        // room.broadcast("hotspot.add", require('./front/scenes/02/hotspots/pc2'))
        // room.broadcast("modal.open",  "email9")
      }
    },
    {
      code:04,
      scene:'',
      fn: (client, cfg) => {
        room.broadcast("modal.close", "email9")
        room.broadcast("modal.close", "prancheta1")
        room.broadcast("modal.close", "prancheta2")
        room.broadcast("modal.open", "video_final")
      }
    }]

    console.log(`Room ${room.roomId}`)
    room.state.timer = 0
}