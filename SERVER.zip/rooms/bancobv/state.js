const colyseus    = require('colyseus');
const schema      = require('@colyseus/schema');
const Schema      = schema.Schema;
const MapSchema   = schema.MapSchema;
const ArraySchema = schema.ArraySchema;

class Player extends Schema { }

schema.defineTypes(Player, {
  peerID:   "string",
  username: "string",
  color:    "number",
  pitch:    "number",
  yaw:      "number"
});

class Inventory extends Schema {
}

schema.defineTypes(Inventory, {
  object: "number"
});

class Variables extends Schema {
  constructor (id, value) {
    super();
    this.id = id
    this.value = value
  }
}

schema.defineTypes(Variables, {
  id:     "string",
  value:  "string"
});

class Scene extends Schema {
    constructor () {
        super();
        this.players    = new MapSchema();
        this.inventory  = new ArraySchema();
        this.variables  = new ArraySchema();
    }
}

schema.defineTypes(Scene, {
  timer:"number",
  scene:"string",
  config:"string",
  inventory: [ Inventory ],
  players: { map: Player },
  variables: [ Variables ]
});

module.exports.Scene        = Scene  
module.exports.Inventory    = Inventory
module.exports.Variables    = Variables
module.exports.Player       = Player