module.exports = client => {
    console.log("[init]")
    client.send("get.missing")
    window.___ = client.viewer
    
    let ready = _.find(client.COLYSEUS.getStateByKey("variables"), { id: 'game.ready' })
    if(ready != undefined && ready.value > 0)
        client.Toast.fire({
            title:'Conectado!',
            html:'',
            icon:'info',
        })
    else
        client.openModal("ready")
}