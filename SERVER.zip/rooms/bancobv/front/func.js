/**
 * Extra custom functions
 */
module.exports = {
    hotSpotFade:(name, pitch, yaw) => {
        return `(event, client) => {
            client.send("scene.fade", {
                name: '${name}',
                pitch: ${pitch + 10},
                yaw: ${yaw},
            })
        }`
    }
}