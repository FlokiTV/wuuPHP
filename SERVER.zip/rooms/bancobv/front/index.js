const fn    = require('./func')
const front = require('./front')

module.exports = {
    default:{
        firstScene: "01",
        type: "equirectangular",
        autoLoad: true,
        // showZoomCtrl: false,
        showFullscreenCtrl: false,
        showControls: true,
        // hotSpotDebug: true,
        // 
        friction:1,
        hfov: 120,
        minHfov: 65,
        maxHfov: 120,
    },
    scenes:{
        "01": require('./scenes/01'),
        "02": require('./scenes/02'),
        // antiga:     require('./scenes/antiga'),
        // nova:       require('./scenes/nova'),
        // servidor:   require('./scenes/servidor'),
    },
    hud:{
        timer:{
            style:{},
            html:'',
            script:{}
        }
    },
    modals: require('./modals'),
    /**
     * Front Events
     */
    created:    front.created.toString(),
    init:       front.init.toString(),
    tick:       front.tick.toString(),
    click:      front.click.toString(),
    mousemove:  front.mousemove.toString()
}