module.exports = client => {
    client.updatePlayersMouse()
    if(client.dragging)
        console.log("[mouse down]")
    else
        console.log("[mouse up]")
        
    if(client.get("mouse") && !client.dragging) //prevent empty
        client.send("mousepos", client.get("mouse"))
}