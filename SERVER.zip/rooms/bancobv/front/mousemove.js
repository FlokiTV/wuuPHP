module.exports = (client, event) =>{
    client.setPlayerMouse(event)
}