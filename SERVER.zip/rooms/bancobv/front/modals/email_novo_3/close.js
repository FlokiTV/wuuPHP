module.exports = (client, el) => {
    client.openModal("transicao_2")
}
