module.exports = (client, el) => {
    el.find(".modal-content").css("width", "calc(100% - 20px)")
    el.find(".modal-content").css("height", "calc(100% - 20px)")
    
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
        // client.openModal("ready")
    }).addClass("has-background-dark")

    var getTranslate  = (position, size) => {
        return `translate(${position.x}px, ${position.y}px) scale(${size})`
    }

    var zoom = add =>{
        let t     = el.find(".img")[0]
        let x     = $(t).attr("data-x")
        let y     = $(t).attr("data-y")
        let s     = $(t).attr("data-size")
        
        let position = {
            x: x != undefined ? parseFloat(x) : 0,
            y: y != undefined ? parseFloat(y) : 0
        }
        let size = ( s == undefined ? 1 : parseFloat(s) )+ ( add ? 0.5 : -0.5 )
        size = (size < .5 ? .5 : size)
        size = (size > 3 ? 3 : size)
        $(t).attr("data-size", size)
        t.style.transform = getTranslate(position, size)
    }
    
    el.find(".ui .add").click( ev =>{
        zoom(1)
    })
    el.find(".ui .rm").click( ev =>{
        zoom(0)
    })

    var page = add =>{
        let pg = parseInt(el.find(".img").attr("data-page")) + (add ? 1 : -1)
        pg = pg > 5 ? 5 : pg
        pg = pg < 1 ? 1 : pg
        el.find(".img img").attr("src", "/textures/manual/"+pg+".png")
        el.find(".img").attr("data-page", pg)
        el.find(".pg").text(pg)
    }
    el.find(".page .add").click( ev =>{
        page(1)
    })
    el.find(".page .rm").click( ev =>{
        page(0)
    })

    interact(`#modal-${id} .img`).draggable({
        modifiers: [
            interact.modifiers.restrict({
                restriction: 'parent',
                endOnly: false
            })
        ],
        listeners: {
            move (event) {
                let t     = event.target
                let x     = $(t).attr("data-x")
                let y     = $(t).attr("data-y")
                let s     = $(t).attr("data-size")
                
                let position = {
                    x: x != undefined ? parseFloat(x) : 0,
                    y: y != undefined ? parseFloat(y) : 0
                }
                let size = ( s == undefined ? 1 : parseFloat(s) )
                position.x += event.dx
                position.y += event.dy
                $(t).attr("data-x", position.x)
                $(t).attr("data-y", position.y)
                $(t).attr("data-size", size)
                t.style.transform = getTranslate(position, size)
            },
        }
    })

}