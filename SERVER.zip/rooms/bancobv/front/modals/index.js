module.exports = {
    video_intro: require("./video_intro"),
    video_final: require("./video_final"),
    // transicao_1:    require("./transicao_1"),
    // transicao_2:    require("./transicao_2"),
    ready:      require("./ready"),
    prancheta:  require("./prancheta"),
    email1:     require("./email_img_1"),
    // re-email1
    mapa:       require("./mapa"),
    email2:     require("./email_img_2"),
    // re-email2
    email3:     require("./email_3"),
    cliente:    require("./cliente"),
    celular:    require("./celular"),
    // re-email3
    email4:     require("./email_img_4"),
    nota:       require("./nota"),

    email5:     require("./email_img_5"),
    inicial:    require("./inicial"),
    /*
        02
    */ 
    email6:     require("./email_img_6"),
    circuito:   require("./circuito"),
    servidor:   require("./servidor"),

    email7:     require("./email_img_7"),
    mesa:       require("./mesa"),

    email8:     require("./email_img_8"),
    mesa_site:  require("./mesa_site"),

    // re_email1:      require("./re_email_1"),
    // re_email2:      require("./re_email_2"),
    // email2:         require("./email_2"),
    // mapa2:          require("./mapa2"),
    // caderno:        require("./caderno"),
    // vendas:         require("./vendas"),
    // email_novo_1:   require("./email_novo_1"),
    // email_novo_2:   require("./email_novo_2"),
    // email_novo_3:   require("./email_novo_3"),
    // email_novo_3_servidor:   require("./email_novo_3_servidor"),
    // email_novo_4:   require("./email_novo_4"),
    // email_novo_5:   require("./email_novo_5"),
    // email_novo_6:   require("./email_novo_6"),
    // email_novo_7:   require("./email_novo_7"),
    // email_novo_8:   require("./email_novo_8"),
    // email_novo_9:   require("./email_novo_9"),
    // email_novo_10:  require("./email_novo_10"),
    // anexo:          require("./anexo"),
    // anexo2:         require("./anexo2"),
    // manual:         require("./manual"),
    // mesa_netshoes:  require("./mesa_netshoes"),
    // mesa_livros:    require("./mesa_livros"),
    // mesa_esmalte:   require("./mesa_esmalte"),
}