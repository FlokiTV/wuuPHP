module.exports = (client, el) => {
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
        // client.openModal("ready")
    })
    el.find('.next').click( ev =>{
        client.AUDIO.play('click')
        var pg = parseInt(el.find('.paginacao').attr('data-pagina')); 
        if(pg == 4) return; 
        el.find('.pagina-'+pg).addClass("is-hidden"); 
        el.find('.pagina-'+(pg+1)).removeClass("is-hidden");
        el.find('.paginacao').attr('data-pagina', pg+1)
    })
    el.find('.prev').click( ev =>{
        client.AUDIO.play('click')
        var pg = parseInt(el.find('.paginacao').attr('data-pagina')); 
        if(pg == 1) return; 
        el.find('.pagina-'+pg).addClass("is-hidden"); 
        el.find('.pagina-'+(pg-1)).removeClass("is-hidden");
        el.find('.paginacao').attr('data-pagina', pg-1)
    })
    el.find('.send-code button').click( ev =>{
        client.AUDIO.play('click')
        client.send('code', el.find('.send-code input').val() )
    })
    el.find("input").on('keyup', e => {
        if (e.key === 'Enter' || e.keyCode === 13)
            client.send('code',  el.find("input").val() )
    })
}