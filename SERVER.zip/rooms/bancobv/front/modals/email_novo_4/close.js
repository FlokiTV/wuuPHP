module.exports = (client, el) => {
    client.openModal("email_novo_5")
}
