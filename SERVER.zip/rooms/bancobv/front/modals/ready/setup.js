module.exports = (client, el) => {
    client.send("player.ready.start")
    el.find(".modal-background").addClass("has-background-dark")

    client.onMessage("player.ready.vote", () =>{
        el.find(".tag-players .tag.is-light").first().addClass("is-success").removeClass("is-light")
    })

    el.find(".modal-close").remove()
    let readybtn    = el.find(".ready-button")
    let tag         =`  <div class="tag is-light is-medium is-rounded">
                            <i class="fas fa-check-square"></i>
                        </div> `
    let count   = Object.keys(client.getPlayers()).length
    for (let i = 0; i < count; i++)
        el.find(".tag-players").append(tag)

    var listenerClients = setInterval(()=>{
        count       = Object.keys(client.getPlayers()).length
        let tags    = el.find(".tag-players .tag").length
        if( tags > count )
            while( tags > count ){
                el.find(".tag").last().remove()
                tags = el.find(".tag-players .tag").length
            }
        if( tags < count )
            while( tags < count ){
                el.find(".tag-players").append(tag)
                tags = el.find(".tag-players .tag").length
            }
    },1000)

    readybtn.click( ev =>{
        client.AUDIO.play('click')
        client.send("player.ready.vote")
        readybtn.addClass("is-success is-loading").removeClass("ready-button is-outlined is-primary")
    })
}