module.exports = (client, el) => {
    client.openModal("video_intro")
}
