module.exports = (client, el) => {
    el.find(".modal-background").addClass("has-background-primary")

    el.find(".modal-content").click(()=>{
        client.AUDIO.play('click')
    })
    el.find(".modal-content").click( ev =>{
        client.closeModal(id)
    })
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
}