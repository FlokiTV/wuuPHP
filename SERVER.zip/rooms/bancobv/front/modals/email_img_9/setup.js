module.exports = (client, el) => {
    $("#modal-email9").css("z-index",99999)
    el.find("button.send-code").click( ev =>{
        client.send('code',  el.find("input").val() )
    })
    el.find("input").on('keyup', e => {
        if (e.key === 'Enter' || e.keyCode === 13)
            client.send('code',  el.find("input").val() )
    })
    /* Close */ 
    el.find(".close").click( ev =>{
        client.closeModal(id)
    })
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
}