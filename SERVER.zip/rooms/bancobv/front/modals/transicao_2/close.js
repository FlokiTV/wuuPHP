module.exports = (client, el) => {
    client.openModal("email_novo_3_servidor")
}
