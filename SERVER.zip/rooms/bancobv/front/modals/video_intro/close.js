module.exports = (client, el) => {
    setTimeout(()=>{
        client.AUDIO.playFile("/audio/email.mp3")
    },1000)
}
