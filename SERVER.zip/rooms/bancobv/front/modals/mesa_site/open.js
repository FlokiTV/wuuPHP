module.exports = (client, el) => {
    $("#ui").css("z-index",99999)
            .css("position", "absolute")
        .find(".email")
            .off()
            .click( ev =>{
                client.openModal("email8")
            })
            .removeClass("is-hidden")
    $("#modal-email8").css("z-index",99999)
}