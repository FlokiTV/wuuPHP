module.exports = (client, el) => {
    $("#ui")
        .find(".email")
            .addClass("is-hidden")
}
