module.exports = (client, el) => {
    el.find(".modal-content")
        .css("width",   "calc(100% - 20px)")
        .css("height",  "calc(100% - 20px)")
    el.find(".modal-background")
        .addClass("has-background-primary")
        .css("background-image",    "url(/bancobv/mesa.png)")
        .css("background-size",     "cover")
        .css("background-position", "center center")
    
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
    // .remove() //REMOVE CLOSE BUTTON
    /**
     * Listeners
     */
    client.onMessage("mesa.send", data =>{
        let width = el.find(".mesa-site .img[data-id='"+data.id+"']").width()
        el.find(".mesa-site .img[data-id='"+data.id+"']")
            .attr("style", `transform:translate(${data.x}px, ${data.y}px); width: ${width}px`)
            .attr("data-x", data.x)
            .attr("data-y", data.y)
    })
    client.onMessage("site.connect", data =>{
        el.find(".dd[data-id='"+data.id+"']")
            .removeClass("dd")
            .css("transform", data.position)
    })
    /**
     * interact
     */
    interact('.dd')
        .draggable({
            modifiers: [
                interact.modifiers.restrict({
                    restriction: 'parent',
                    endOnly: false
                })
            ],
            listeners: {
                move (event) {
                    let position = {
                        id: $(event.target).attr("data-id"),
                        x:  $(event.target).attr("data-x") == undefined ? 0 : parseFloat($(event.target).attr("data-x")),
                        y:  $(event.target).attr("data-y") == undefined ? 0 : parseFloat($(event.target).attr("data-y")),
                    }
                    position.x += event.dx
                    position.y += event.dy
                    client.send("mesa.send", position)
                    $(event.target).attr("data-x", position.x)
                    $(event.target).attr("data-y", position.y)
                    event.target.style.transform = `translate(${position.x}px, ${position.y}px)`
                },
            }
        })
        interact(".mesa-site .sockets div")
        .dropzone({
            accept: '.dd',
            overlap: .95,
            ondrop: function (event) {
                let accept  = $(event.target).attr("data-accept")
                let accept2 = $(event.relatedTarget).attr("data-id")
                let socket = $(event.target).attr("data-transform")
                
                if(accept != undefined && accept2 != undefined && accept == accept2){
                    client.send("site.connect", {
                        id: accept2,
                        position: socket
                    })
                    el.find(".dd[data-id='"+accept2+"']")
                        .removeClass("dd")
                        .css("transform", socket)
                    if(!el.find(".mesa-site .img.dd").length)
                        client.send('code', 'site')
                }
            }
        })

}