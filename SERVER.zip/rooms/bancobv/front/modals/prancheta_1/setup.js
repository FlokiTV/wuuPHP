module.exports = (client, el) => {
    el.find(".modal-content").css("width", "calc(100% - 20px)")
    el.find(".modal-content").css("height", "calc(100% - 20px)")
    $("#modal-prancheta1").css("z-index",999)
    var startPos = ''
    client.onMessage("prancheta.send", data =>{
        el.find(".draggable[data-id='"+data.id+"']")
            .attr("style", `transform:translate(${data.x}px, ${data.y}px)`)
            .attr("data-x", data.x)
            .attr("data-y", data.y)
    })

    interact('#modal-prancheta1 .draggable')
    .draggable({
        modifiers: [
            interact.modifiers.restrict({
                restriction: 'parent',
                endOnly: false
            })
        ],
        listeners: {
            start (event) {
                var rect = interact.getElementRect(event.target);
                startPos = {
                    x: rect.left + rect.width  / 2,
                    y: rect.top  + rect.height / 2
                }
            },
            move (event) {
                let position = {
                    id: $(event.target).attr("data-id"),
                    x:  $(event.target).attr("data-x") == undefined ? 0 : parseFloat($(event.target).attr("data-x")),
                    y:  $(event.target).attr("data-y") == undefined ? 0 : parseFloat($(event.target).attr("data-y")),
                }
                position.x += event.dx
                position.y += event.dy
                client.send("prancheta.send", position)

                $(event.target).attr("data-x", position.x)
                $(event.target).attr("data-y", position.y)
                event.target.style.transform = `translate(${position.x}px, ${position.y}px)`
            },
        }
    })
    if(false)
    interact(".drops .zone")
    .dropzone({
        accept: '.draggable',
        overlap: .5,
        ondrop: function (event) {
            let accept  = $(event.target).attr("data-accept")
            let accept2 = $(event.relatedTarget).attr("data-accept")
            if(accept != undefined && accept2 != undefined && accept == accept2){
                client.Toast.fire({
                    title:'OK!',
                    html:'',
                    icon:'info',
                })
            }
        },
        ondragenter: function (event) {
            var draggableElement = event.relatedTarget,
                dropzoneElement  = event.target,
                dropRect         = interact.getElementRect(dropzoneElement),
                dropCenter       = {
                    x: dropRect.left + dropRect.width  / 2,
                    y: dropRect.top  + dropRect.height / 2
                };
        }
    })
    .on('dropactivate', function (event) {
        // event.target.classList.add('drop-activated')
    })

    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
}