module.exports = (client, el) => {
    setTimeout(()=>{
        client.AUDIO.play("notification")
    },1000)
}
