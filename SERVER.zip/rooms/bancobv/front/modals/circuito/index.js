const fs    = require('fs')
const setup = require('./setup')
const open  = require('./open')
const close = require('./close')
module.exports = {
    setup:  setup.toString(),
    open:   open.toString(),
    close:  close.toString(),
    html:   fs.readFileSync(__dirname+'/index.html', 'utf8')  
}