module.exports = {
    created:    require("./created"),
    init:       require("./init"),
    tick:       require("./tick"),
    click:      require("./click"),
    mousemove:  require("./mousemove")
}