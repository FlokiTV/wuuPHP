module.exports = {
    id: "pc",
    pitch: -6,
    yaw: -150,
    type: "info",
    text: "Computador",
    clickHandlerFunc: '(event, client) => { client.openModal("email_novo_1") }'
}