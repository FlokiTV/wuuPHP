module.exports = (hotSpotDiv, args) => {
    hotSpotDiv.classList.add('cliente-tooltip');
    var span        = document.createElement('span');
    var style       = document.createElement('style');
    style.innerHTML = `'%css%'`
    span.innerHTML  = args;
    hotSpotDiv.appendChild(style);
    hotSpotDiv.appendChild(span);
    if(!args) $(span).remove()
    span.style.width        = span.scrollWidth - 20 + 'px';
    span.style.marginLeft   = -(span.scrollWidth - hotSpotDiv.offsetWidth) / 2 + 'px';
    span.style.marginTop    = -span.scrollHeight - 12 + 'px';
}