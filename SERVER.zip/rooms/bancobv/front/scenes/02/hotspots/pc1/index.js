module.exports = {
    id: "pc1",
    // -6.96901884964497, Center Yaw: 63.61
    pitch: -6.96,
    yaw: -300,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta1") }'
}