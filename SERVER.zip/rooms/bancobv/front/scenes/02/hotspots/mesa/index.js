module.exports = {
    id: "mesa",
    //-17.89244421305733, Center Yaw: -133.29
    pitch:  -17.89,
    yaw:    -133.29,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("mesa") }'
}