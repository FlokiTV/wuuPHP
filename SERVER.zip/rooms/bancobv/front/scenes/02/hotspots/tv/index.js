module.exports = {
    id: "tv",
    // 3.13473301379861, Center Yaw: -251.762
    pitch: 3.13,
    yaw: -251.76,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("servidor") }'
}