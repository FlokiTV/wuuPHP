module.exports = {
    id: "ti",
    // -0.9365652073683632, Center Yaw: 30.50
    pitch:  -0.93,
    yaw: 30.50,
    type: "info",
    text: "Andar de T.I.",
    clickHandlerFunc: '(event, client) => { client.openModal("circuito") }'
}