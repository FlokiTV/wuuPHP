module.exports = {
    id: "pc",
    // -6.96901884964497, Center Yaw: 63.61
    pitch: -6.96,
    yaw: 63.61,
    type: "info",
    text: "Computador",
    clickHandlerFunc: '(event, client) => { client.openModal("email6") }'
}