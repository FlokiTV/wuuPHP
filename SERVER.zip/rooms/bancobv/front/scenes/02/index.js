module.exports = {
    panorama: "/bancobv/maps/02.jpg",
    open:`client => {
        client.setupModal("circuito")
        client.setupModal("mesa")
        client.setupModal("mesa_site")
    }`,
    hotSpots:[
        require('./hotspots/pc'),
        require('./hotspots/tv'),
        require('./hotspots/ti'),
    ]
}