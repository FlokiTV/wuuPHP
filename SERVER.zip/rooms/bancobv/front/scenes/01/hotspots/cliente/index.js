const fs    = require('fs')
let css     = fs.readFileSync(__dirname+'/css.css', 'utf8')

module.exports = {
    id: "cliente",
    // -18.741764619591063, Center Yaw: -2.885079826930737
    //  -7.5772257760293655, Center Yaw: -143.14
    pitch: -8,
    yaw: -143.14,
    scale:true,
    cssClass:'hotspot-cliente',
    createTooltipArgs: "Olá, poderia me ajudar?",
    createTooltipFunc: require('./tooltip').toString().replace("'%css%'", css),
    clickHandlerFunc:  require('./click').toString()
}