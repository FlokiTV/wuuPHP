module.exports = {
    id: "mapa",
    // 15.01302671068624, Center Yaw: -76.26
    pitch: 15.01,
    yaw: -76.26,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("mapa") }'
}