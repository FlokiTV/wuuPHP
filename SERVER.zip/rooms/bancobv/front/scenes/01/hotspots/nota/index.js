module.exports = {
    id: "nota",
    pitch: -19.51,
    yaw: -56,
    type: "info",
    text: "Anotação",
    clickHandlerFunc: '(event, client) => { client.openModal("nota") }'
}