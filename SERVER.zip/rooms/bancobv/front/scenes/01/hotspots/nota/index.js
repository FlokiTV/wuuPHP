module.exports = {
    id: "nota",
    // -43.67847043400316, Center Yaw: 88.70
    pitch: -43.67,
    yaw: 88.70,
    type: "info",
    text: "Anotações",
    clickHandlerFunc: '(event, client) => { client.openModal("nota") }'
}