module.exports = {
    id: "tv2",
    // 11.849186196303299, Center Yaw: -35.498382684145376
    pitch: 1, 
    yaw: -123,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("inicial") }'
}