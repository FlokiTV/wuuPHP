module.exports = {
    id: "tv",
    // 11.849186196303299, Center Yaw: -35.498382684145376
    pitch: 11.84,
    yaw: -35.49,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta") }'
}