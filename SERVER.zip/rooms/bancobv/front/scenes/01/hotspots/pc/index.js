module.exports = {
    id: "pc",
    // -5.165809955060279, Center Yaw: -166.5915145208635
    pitch: -5.16,
    yaw: -166.59,
    type: "info",
    text: "Computador",
    clickHandlerFunc: '(event, client) => { client.openModal("email1") }'
}