module.exports = {
    id: "mapa",
    pitch: 4.11,
    yaw: -55,
    type: "info",
    text: "Mapa",
    clickHandlerFunc: '(event, client) => { client.openModal("mapa") }'
}