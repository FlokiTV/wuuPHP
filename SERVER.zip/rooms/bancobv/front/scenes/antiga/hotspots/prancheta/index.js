module.exports = {
    id: "prancheta",
    // 11.849186196303299, Center Yaw: -35.498382684145376
    pitch: -41,
    yaw: -219,
    type: "info",
    text: "Prancheta",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta") }'
}