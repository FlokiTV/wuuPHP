module.exports = {
    id: "manual",
    pitch: -30,
    yaw: 38,
    scale: true,
    type: "info",
    text: "Manual",
    clickHandlerFunc: '(event, client) => { client.openModal("manual") }'
}