module.exports = {
    panorama: "/bancobv/maps/03.jpg",
    open:`client => {
    
    }`,
    hotSpots:[
        require('./hotspots/pc'),
        require('./hotspots/pc1'),
        require('./hotspots/pc2'),
    ]
}