module.exports = {
    id: "pc1",
    // -6.472302852631114, Center Yaw: 96.58
    pitch: -6.47,
    yaw: 96.58,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta1") }'
}