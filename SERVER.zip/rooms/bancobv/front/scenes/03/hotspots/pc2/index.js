module.exports = {
    id: "pc2",
    // -8.542976007668287, Center Yaw: 119.39
    pitch: -6.54,
    yaw: 119.39,
    type: "info",
    text: "",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta2") }'
}