module.exports = (room, client, options) => {
    console.log(`Join ${client.sessionId}`)
    let ct = room.getPlayerClient(client.sessionId)
    ct.send("config", room.Game.config) //send config to player
    room.state.players[client.sessionId] = new room.Game.state.Player()
    room.broadcast("join", { //send to all clients
      client: client.sessionId
    })
}