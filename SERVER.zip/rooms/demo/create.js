module.exports = (room, options) => {
    room.setMetadata({ name: options.name })
    room.state.inventory.push(new room.Game.state.Inventory())
    room.name = options.name
    room.missionList = [
      {
        code: 123,
        scene:'',
        fn:(client, cfg) => {
          room.broadcast("modal.close", "email_1")
          room.broadcast("modal.close", "prancheta")
          room.broadcast("hotspot.remove", {id:"prancheta", selector: false })
          room.broadcast("hotspot.remove", {id:"pc", selector: false })
          room.broadcast("dica.change", 2)
          let pc = { ...require('./scenes/demo/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email_1","email_2")
          room.broadcast("hotspot.add", pc)
        }
      },
      {
        code: "sucesso",
        scene:'',
        fn:(client, cfg) => {
          room.broadcast("modal.close", "email_2")
          room.broadcast("modal.open", "video_final")
        }
      }
    ]

    console.log(`Room ${room.roomId}`)
    room.state.timer = 0
}