module.exports = {
    id: "quadro",
    pitch: 14.45,
    yaw: -94.52,
    type: "info",
    text: "Quadro",
    clickHandlerFunc: '(event, client) => { client.openModal("quadro") }'
}