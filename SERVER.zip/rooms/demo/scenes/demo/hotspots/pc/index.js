module.exports = {
    id: "pc",
    pitch: -19.53,
    yaw: 17.91,
    type: "info",
    text: "Computador",
    clickHandlerFunc: '(event, client) => { client.openModal("email_1") }'
}