module.exports = {
    id: "prancheta",
    pitch: -23.04,
    yaw: -22.27,
    type: "info",
    text: "Prancheta",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta") }'
}