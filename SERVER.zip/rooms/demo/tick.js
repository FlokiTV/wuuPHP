const _ = require("lodash")

module.exports = (room, deltaTime)=>{
    // Game prepare to start
    let player_ready = _.find(room.getStateByKey("variables"), { id: 'player.ready' })
    if(player_ready != undefined){// FINDED!
        let clients = Object.keys(room.getStateByKey("players")).length
        let votes   = parseInt(player_ready.value)
        if( votes == clients ){
            let ind = _.findIndex(room.getStateByKey("variables"), { id: 'player.ready' })
            room.getStateByKey("variables").splice(ind, 1);
            console.log("votation end")
            room.state.variables.push( new room.Game.state.Variables('game.ready', '1') )
            room.db()
                .find({ name: room.name })
                .assign({ locked: true})
                .write()
            room.broadcast("modal.close", "ready")
            // room.broadcast("modal.open", "video_intro")
            room.TIMER = room.clock.setInterval(()=>{
                room.state.timer++
            },1000)
        }
    }
    if(room.scene_end){
        room.broadcast("toast.fire", {
            title:'Código aceito!',
            html:'Etapa concluida',
            icon:'success',
        })
        room.broadcast("audio.play","/audio/success.mp3")
        let cfg = {...room.missionList[0]}
        room.missionList.shift()
        cfg.fn(room, cfg)
        room.scene_end = false
        if(!room.missionList.length) room.TIMER.clear()
    }
}