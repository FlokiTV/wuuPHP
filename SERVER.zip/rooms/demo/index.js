module.exports = {
    state   : {},
    create  : {},
    listener: {},
    auth    : {},
    tick    : {},
    join    : {},
    leave   : {},
    destroy : {},
    config  : {},
    init:(room, options) =>{
        this.state      = require("./state")
        this.create     = require("./create")
        this.listener   = require("./listener")
        this.auth       = require("./auth")
        this.tick       = require("./tick")
        this.join       = require("./join")
        this.leave      = require("./leave")
        this.destroy    = require("./destroy")
        this.config     = require("./config")
        room.setState( new this.state.Scene() )
        room.state.scene = this.config.default.firstScene
        return this
    }
}
