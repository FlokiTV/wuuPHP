module.exports = {
    ready:          require("./ready"),
    quadro:         require("./quadro"),
    prancheta:      require("./prancheta"),
    email_1:        require("./email_1"),
    email_2:        require("./email_2"),
    video_final:    require("./video_final")
}