module.exports = (client, el) => {
    el.find("#email2-pass").click( ev =>{
        client.send('code',  el.find("#email2-pass-value").val() )
    })
    el.find(".toggle_fullscreen").click( ev =>{
        if(el.find(".modal-content").hasClass("fullscreen"))
            el.find(".modal-content").removeClass("fullscreen")
        else
            el.find(".modal-content").addClass("fullscreen")
    })
    el.find(".close").click( ev =>{
        client.closeModal(id)
    })
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
    el.find("#email2-pass-value").on('keyup', e => {
        if (e.key === 'Enter' || e.keyCode === 13)
            client.send('code',  el.find("#email2-pass-value").val() )
    })
}