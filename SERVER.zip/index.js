const { gameServer } = require('./bin/server')
const port = process.env.PORT || 3001

require('./bin/admin')(gameServer)
require('./bin/lobby')(gameServer)

/**
 * GAMES ROOM
 */
let roomName  = require('./rooms/bancobv')
const Room    = require('./bin/room')(roomName)
gameServer.define('demo', Room)
  .on("create", (room)  => { 
    // console.log("room created:", room.roomId)
  })
  .on("dispose", (room) => { 
    // console.log("room disposed:", room.roomId)     
  })
  .on("join", (room, client) => { 
    // console.log(client.id, "joined", room.roomId)  
  })
  .on("leave", (room, client) => { 
    // console.log(client.id, "left", room.roomId)
  })

gameServer.listen(port)
console.log(`Listening on localhost:${ port }`)