module.exports = (client, el) => {
    $("#ui")
        .find(".email")
            .off()
            .click( ev =>{
                client.openModal("email_novo_3_servidor")
            })
            .removeClass("is-hidden")

    el.find(".toggle_fullscreen").click( ev =>{
        if(el.find(".modal-content").hasClass("fullscreen"))
            el.find(".modal-content").removeClass("fullscreen")
        else
            el.find(".modal-content").addClass("fullscreen")
    })
    el.find("button").click(()=>{
        client.AUDIO.play('click')
    })
    el.find(".close").click( ev =>{
        client.closeModal(id)
    })
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
}