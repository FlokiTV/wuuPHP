module.exports = (client, el) => {
    el.find(".modal-content")
    .css("width",   "calc(100% - 20px)")
    .css("height",  "calc(100% - 20px)")
    el.find(".modal-background")
    .addClass("has-background-primary")
    .css("background-image",    "url(/textures/mesa.jpg)")
    .css("background-size",     "cover")
    .css("background-position", "center center")
    $("#ui").css("z-index",99999)
            .css("position", "absolute")
        .find(".email")
            .click( ev =>{
                client.openModal("email_novo_5")
            })
            .removeClass("is-hidden")
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
        // client.openModal("ready")
    })
    .remove() //REMOVE CLOSE BUTTON

    client.onMessage("mesa.send", data =>{
        el.find(".mesa img[data-id='"+data.id+"']")
            .attr("style", `transform:translate(${data.x}px, ${data.y}px)`)
            .attr("data-x", data.x)
            .attr("data-y", data.y)
    })

    interact('.mesa img')
    .draggable({
        modifiers: [
            interact.modifiers.restrict({
                restriction: 'parent',
                endOnly: false
            })
        ],
        listeners: {
            move (event) {
                let position = {
                    id: $(event.target).attr("data-id"),
                    x:  $(event.target).attr("data-x") == undefined ? 0 : parseFloat($(event.target).attr("data-x")),
                    y:  $(event.target).attr("data-y") == undefined ? 0 : parseFloat($(event.target).attr("data-y")),
                }
                position.x += event.dx
                position.y += event.dy
                client.send("mesa.send", position)
                $(event.target).attr("data-x", position.x)
                $(event.target).attr("data-y", position.y)
                event.target.style.transform = `translate(${position.x}px, ${position.y}px)`
            },
        }
    })

}