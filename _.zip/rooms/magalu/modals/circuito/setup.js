module.exports = (client, el) => {
    el.find(".modal-content").css("width", "calc(100% - 20px)")
    el.find(".modal-content").css("height", "calc(100% - 20px)")

    client.set("circuito.code", [
        'amarelo',
        'verde',
        'vermelho',
        'rosa'
    ])

    client.onMessage("circuito.send", data =>{
        el.find(".dd[data-id='"+data.id+"']")
            .attr("style", `transform:translate(${data.x}px, ${data.y}px)`)
            .attr("data-x", data.x)
            .attr("data-y", data.y)
    })
    client.onMessage("circuito.connect", data =>{
        let _circuit_order = client.get("circuito.code")
        _circuit_order.shift()
        client.set("circuito.code", _circuit_order)
        console.log(data)
        let sv_img = 5 - _circuit_order.length
        console.log(sv_img)
        $("#modal-servidor img").attr("src", `/textures/servidor/${sv_img}.png`)
        el.find(".dd[data-id='"+data.id+"']")
            .removeClass("dd")
            .css("transform", `translate(${data.x}px, ${data.y}px)`)
    })

    interact('#modal-circuito .dd')
    .draggable({
        modifiers: [
            interact.modifiers.restrict({
                restriction: 'parent',
                endOnly: true
            })
        ],
        listeners: {
            move (event) {
                let position = {
                    id: $(event.target).attr("data-id"),
                    x:  $(event.target).attr("data-x") == undefined ? 0 : parseFloat($(event.target).attr("data-x")),
                    y:  $(event.target).attr("data-y") == undefined ? 0 : parseFloat($(event.target).attr("data-y")),
                }
                position.x += event.dx
                position.y += event.dy
                client.send("circuito.send", position)

                $(event.target).attr("data-x", position.x)
                $(event.target).attr("data-y", position.y)
                event.target.style.transform = `translate(${position.x}px, ${position.y}px)`
            },
        }
    })

    interact("#modal-circuito .drops .zone")
    .dropzone({
        accept: '.dd',
        overlap: .3,
        ondrop: function (event) {
            let accept  = $(event.target).attr("data-accept")
            let accept2 = $(event.relatedTarget).attr("data-id")
            let socket = {
                top:    $(event.target).position().top,
                left:   $(event.target).position().left
            }
            let _circuit_order = client.get("circuito.code")
            if(accept != undefined && accept2 != undefined && accept == accept2 && _circuit_order[0] == accept2){
                client.send("circuito.connect", {
                    id: $(event.relatedTarget).attr("data-id"),
                    x: socket.left,
                    y: socket.top
                })
                el.find(".dd[data-id='"+accept2+"']")
                    .removeClass("dd")
                    .css("transform", `translate(${socket.left}px, ${socket.top}px)`)
                if(_circuit_order.length - 1 == 0){
                    client.send('code', 'circuito')
                    client.send('drag.conn.reset', 'circuito')
                }
            }
        }
    })

    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
}