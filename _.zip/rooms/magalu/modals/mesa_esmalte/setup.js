module.exports = (client, el) => {
    el.find(".modal-content")
        .css("width",   "calc(100% - 20px)")
        .css("height",  "calc(100% - 20px)")
    el.find(".modal-background")
        .addClass("has-background-primary")
        .css("background-image",    "url(/textures/mesa.jpg)")
        .css("background-size",     "cover")
        .css("background-position", "center center")
    $("#ui").css("z-index",99999)
            .css("position", "absolute")
        .find(".email")
            .off()
            .click( ev =>{
                client.openModal("email_novo_8")
            })
            .removeClass("is-hidden")
    $("#modal-email_novo_8").css("z-index",99999)
    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
    })
    .remove() //REMOVE CLOSE BUTTON

}