module.exports = (room, options) => {
    room.setMetadata({ name: options.name })
    room.state.inventory.push(new room.Game.state.Inventory())
    room.name = options.name
    room.missionListTEMP = []
    room.missionList = [{
      code: 4132,
      scene:'',
      events:[
        [ "modal.close", "email1" ],
        [ "hotspot.remove", { id:"prancheta", selector: false } ],
        [ "hotspot.remove", { id:"pc", selector: false } ],
        [ "dica.change", 2 ],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./scenes/antiga/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email2")
          return pc
        }],
        [ "modal.open", "re_email1" ]
      ],
      fn:(client, cfg) => {
        room.broadcast("modal.close", "email1")
        room.broadcast("hotspot.remove", { id:"prancheta", selector: false })
        room.broadcast("hotspot.remove", { id:"pc", selector: false })
        room.broadcast("dica.change", 2)
        let pc = { ...require('./scenes/antiga/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email2")
        room.broadcast("hotspot.add", pc)
        room.broadcast("modal.open", "re_email1")
      }
    },
    {
      code: 322,
      scene:'',
      events:[
        [ "modal.close", "email2" ],
        [ "hotspot.remove", {id:"pc", selector: false } ],
        [ "dica.change", 3 ],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./scenes/antiga/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","vendas")
          return pc
        }],
        [ "hotspot.add", require('./scenes/antiga/hotspots/cliente') ],
        [ "modal.open", "re_email2" ]
      ],
      fn:(client, cfg) => {
        room.broadcast("modal.close", "email2")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("dica.change", 3)
        let pc = { ...require('./scenes/antiga/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","vendas")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./scenes/antiga/hotspots/cliente'))
        room.broadcast("modal.open", "re_email2")
      }
    },
    {
      code:5217,
      scene:'',
      events:[
        [ "modal.close", "vendas" ],
        [ "modal.open", "email3" ],
        [ "hotspot.remove", {id:"pc", selector: false } ],
        [ "hotspot.remove", {id:"cliente", selector: false } ],
        [ "dica.change", 4 ]
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "vendas")
        room.broadcast("modal.open", "email3")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"cliente", selector: false })
        // room.broadcast("scene.change", "nova")
        room.broadcast("dica.change", 4)
        room.setScene("nova")
      }
    },
    {
      code:'sucesso',
      scene:'',
      events:[
        [ "modal.close", "email_novo_1" ],
        [ "hotspot.remove", {id:"pc", selector: false } ],
        [ "hotspot.remove", {id:"caderno", selector: false } ],
        [ "hotspot.add", ()=>{
          let pc = { ...require('./scenes/nova/hotspots/pc') }
          pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email_novo_1","email_novo_2")
          return pc
        }],
        [ "dica.change", 5 ],
        [ "audio.play", '/audio/notification.mp3' ]
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email_novo_1")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        let pc = { ...require('./scenes/nova/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email_novo_1","email_novo_2")
        room.broadcast("hotspot.remove", {id:"caderno", selector: false })
        room.broadcast("hotspot.add", pc)
        room.broadcast("dica.change", 5)
        room.broadcast("audio.play", '/audio/notification.mp3')
        // room.broadcast("modal.open", "email3")
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code:'1653',
      scene:'',
      events:[
        [ "modal.close", "email_novo_2" ],
        [ "modal.open", "email_novo_3" ],
        [ "dica.change", 6 ]
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email_novo_2")
        // room.broadcast("scene.change", "servidor")
        room.setScene("servidor")
        room.broadcast("modal.open", "email_novo_3")
        room.broadcast("dica.change", 6)
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code:'circuito',
      scene:'',
      events:[
        [ "modal.close", "circuito" ],
        [ "modal.close", "email_novo_3_servidor" ],
        [ "modal.open", "mesa" ],
        [ "modal.open", "email_novo_5" ],
        [ "dica.change", 7 ]
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "circuito")
        room.broadcast("modal.close", "email_novo_3_servidor")
        room.broadcast("modal.open", "mesa")
        room.broadcast("modal.open", "email_novo_5")
        room.broadcast("dica.change", 7)
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code: 268418795,
      scene: '',
      events:[
        [ "modal.close", "mesa" ],
        [ "modal.close", "email_novo_5" ],
        [ "modal.open",  "mesa_netshoes" ],
        [ "modal.open",  "email_novo_6" ],
        [ "dica.change", 8 ]
      ],
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "mesa")
        room.broadcast("modal.close", "email_novo_5")
        room.broadcast("modal.open",  "mesa_netshoes")
        room.broadcast("modal.open",  "email_novo_6")
        room.broadcast("dica.change", 8)
      }
    },
    {
      code:'netshoes',
      scene:'',
      events:[
        [ "modal.close", "mesa_netshoes" ],
        [ "modal.close", "email_novo_6" ],
        [ "modal.open",  "mesa_livros" ],
        [ "modal.open",  "email_novo_7" ],
        [ "dica.change", 9 ]
      ],
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_netshoes")
        room.broadcast("modal.close", "email_novo_6")
        room.broadcast("modal.open",  "mesa_livros")
        room.broadcast("modal.open",  "email_novo_7")
        room.broadcast("dica.change", 9)
      }
    },
    {
      code:42,
      scene:'',
      events:[
        [ "modal.close", "mesa_livros" ],
        [ "modal.close", "email_novo_7" ],
        [ "modal.open",  "mesa_esmalte" ],
        [ "modal.open",  "email_novo_8" ],
        [ "dica.change", 10 ]
      ],
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_livros")
        room.broadcast("modal.close", "email_novo_7")
        room.broadcast("modal.open",  "mesa_esmalte")
        room.broadcast("modal.open",  "email_novo_8")
        room.broadcast("dica.change", 10)
      }
    },
    {
      code:121810,
      scene:'',
      events:[
        [ "modal.close", "mesa_esmalte" ],
        [ "modal.close", "email_novo_8" ],
        [ "modal.open",  "email_novo_9" ]
      ],
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_esmalte")
        room.broadcast("modal.close", "email_novo_8")
        room.broadcast("modal.open",  "email_novo_9")
      }
    }]

    console.log(`Room ${room.roomId}`)
    room.state.timer = 0
}