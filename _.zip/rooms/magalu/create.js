module.exports = (room, options) => {
    room.setMetadata({ name: options.name })
    room.state.inventory.push(new room.Game.state.Inventory())
    room.name = options.name
    room.missionList = [{
      code: 4132,
      scene:'',
      fn:(client, cfg) => {
        room.broadcast("modal.close", "email1")
        room.broadcast("hotspot.remove", {id:"prancheta", selector: false })
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("dica.change", 2)
        let pc = { ...require('./scenes/antiga/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","email2")
        room.broadcast("hotspot.add", pc)
        room.broadcast("modal.open", "re_email1")
      }
    },
    {
      code: 322,
      scene:'',
      fn:(client, cfg) => {
        room.broadcast("modal.close", "email2")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("dica.change", 3)
        let pc = { ...require('./scenes/antiga/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email1","vendas")
        room.broadcast("hotspot.add", pc)
        room.broadcast("hotspot.add", require('./scenes/antiga/hotspots/cliente'))
        room.broadcast("modal.open", "re_email2")
      }
    },
    {
      code:5217,
      scene:'',
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "vendas")
        room.broadcast("modal.open", "email3")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        room.broadcast("hotspot.remove", {id:"cliente", selector: false })
        room.broadcast("scene.change", "nova")
        room.broadcast("dica.change", 4)
      }
    },
    {
      code:'sucesso',
      scene:'',
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email_novo_1")
        room.broadcast("hotspot.remove", {id:"pc", selector: false })
        let pc = { ...require('./scenes/nova/hotspots/pc') }
        pc.clickHandlerFunc = pc.clickHandlerFunc.replace("email_novo_1","email_novo_2")
        room.broadcast("hotspot.remove", {id:"caderno", selector: false })
        room.broadcast("hotspot.add", pc)
        room.broadcast("dica.change", 5)
        room.broadcast("audio.play", '/audio/notification.mp3')
        // room.broadcast("modal.open", "email3")
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code:'1653',
      scene:'',
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "email_novo_2")
        room.broadcast("scene.change", "servidor")
        room.broadcast("modal.open", "email_novo_3")
        room.broadcast("dica.change", 6)
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code:'circuito',
      scene:'',
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "circuito")
        room.broadcast("modal.close", "email_novo_3_servidor")
        room.broadcast("modal.open", "mesa")
        room.broadcast("modal.open", "email_novo_5")
        room.broadcast("dica.change", 7)
        // room.broadcast("hotspot.remove", {id:"cliente", selector: false })
      }
    },
    {
      code: 268418795,
      scene: '',
      fn: (client, cfg) =>{
        room.broadcast("modal.close", "mesa")
        room.broadcast("modal.close", "email_novo_5")
        room.broadcast("modal.open",  "mesa_netshoes")
        room.broadcast("modal.open",  "email_novo_6")
        room.broadcast("dica.change", 8)
      }
    },
    {
      code:'netshoes',
      scene:'',
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_netshoes")
        room.broadcast("modal.close", "email_novo_6")
        room.broadcast("modal.open",  "mesa_livros")
        room.broadcast("modal.open",  "email_novo_7")
        room.broadcast("dica.change", 9)
      }
    },
    {
      code:42,
      scene:'',
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_livros")
        room.broadcast("modal.close", "email_novo_7")
        room.broadcast("modal.open",  "mesa_esmalte")
        room.broadcast("modal.open",  "email_novo_8")
        room.broadcast("dica.change", 10)
      }
    },
    {
      code:121810,
      scene:'',
      fn: (client, cfg) => {
        room.broadcast("modal.close", "mesa_esmalte")
        room.broadcast("modal.close", "email_novo_8")
        room.broadcast("modal.open",  "email_novo_9")
      }
    }]

    console.log(`Room ${room.roomId}`)
    room.state.timer = 0
}