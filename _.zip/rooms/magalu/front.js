module.exports = {
    created: client => {
        /**
         * Dica
         */
        client.onMessage("dica.change", dica =>{
            $("#ui .dica img").attr("src", `/dicas/${dica}.jpg`)
        })
        /**
         * Scene
         */
        client.onMessage("scene.change", scene =>{
            client.changeScene(scene)
        })
        client.onMessage("scene.fade", scene =>{
            console.log("[scene.fade]")
            client.viewer.lookAt(
                // client.get("mouse").pitch, 
                // client.get("mouse").yaw,
                scene.pitch,
                scene.yaw,
                65,
                600,
                () =>{
                    $(".pnlm-load-box").html("<button class='button is-loading'></button>")
                    let __scene   = client.COLYSEUS.getStateByKey("scene")
                    let __config  = client.viewer.getConfig().scenes[__scene]
                    if(__config.open){
                        console.log(__config.open)
                        let script = eval(__config.open)
                        script(client)
                    }
                    client.viewer.loadScene(client.COLYSEUS.getStateByKey("scene"),
                        client.viewer.getPitch(), 
                        client.viewer.getYaw())
                }
            )
        })
        /**
         * HotSpot
         */
        client.onMessage("hotspot.remove", hs =>{
            console.log("[hotspot.remove]")
            client.removeHotSpot(hs.id, hs.selector)
        })
        client.onMessage("hotspot.add", hs =>{
            console.log("[hotspot.add]")
            client.addHotSpot(hs)
        })
        /**
         * Audio
         */
        client.onMessage("audio.play", audio =>{
            let alert = new Audio(audio)
            alert.play()
        })
        /**
         * Modal
         */
        client.onMessage("modal.open", id =>{
            client.openModal(id)
        })
        client.onMessage("modal.close", id =>{
            client.closeModal(id)
        })
        client.onMessage("toast.fire", cfg =>{
            client.Toast.fire(cfg)
        })
        /**
         * System
         */
        client.onMessage("leave", ev =>{
            console.log("[leave]", ev.client)
            client.removeHotSpot(ev.client, ".player-"+ev.client)
        })
    },
    init: client => {
        console.log("[init]")
        window.___ = client.viewer
        
        let ready = _.find(client.COLYSEUS.getStateByKey("variables"), { id: 'game.ready' })
        if(ready != undefined && ready.value > 0)
            client.Toast.fire({
                title:'Conectado!',
                html:'',
                icon:'info',
            })
        else
            client.openModal("ready")
    },
    tick: client => {
        client.updatePlayersMouse()
        if(client.dragging)
            console.log("[mouse down]")
        else
            console.log("[mouse up]")
            
        if(client.get("mouse") && !client.dragging) //prevent empty
            client.send("mousepos", client.get("mouse"))
    },
    click: (client, event)=>{
        console.log("[click]")
    },
    mousemove: (client, event) =>{
        client.setPlayerMouse(event)
    }
}