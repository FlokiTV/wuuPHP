module.exports = (room, client, options, request)=>{
    console.log("Auth")
    return true
}