const fn = require('../func')

module.exports = {
    floresta1:{
        panorama: "https://i.imgur.com/HC3ccY1.jpg",
        close:`client => {
            
        }`,
        open: `client => {
            clearInterval(client.get("timer.click"))
            let au  = client.AUDIO.playFile('/audio/ambience/crickets.mp3')
            au.loop = true
            setInterval(()=>{
                $(".pnlm-hotspot-base").off("click")
                $(".pnlm-hotspot-base").click(()=>{
                    console.log("/audio/ambience/walk/"+(Math.floor(Math.random() * 4) + 1)+".mp3")
                    client.AUDIO.playFile("/audio/ambience/walk/"+(Math.floor(Math.random() * 5) + 1)+".mp3")
                })
            },200)
        }`,
        hotSpots:[
            {
                id: "floresta2",
                pitch: -9,
                yaw: 148,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta2', -9, 148)
            }
        ]
    },
    floresta2:{
        panorama: "https://i.imgur.com/qfk16Bs.jpg",
        hotSpots:[
            {
                id: "floresta1",
                pitch: -11,
                yaw: 324,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta1', -11, 324)
            },
            {
                id: "floresta3",
                pitch: -13.5,
                yaw: 167.7,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta3', -13.5, 167.7)
            },
            {
                id: "floresta4",
                pitch: -13,
                yaw: 216,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta4', -13, 216)
            },
        ]
    },
    floresta3:{
        panorama: "https://i.imgur.com/5qPohPF.jpg",
        hotSpots:[
            {
                id: "floresta2",
                pitch: -10,
                yaw: 345,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta2', -10, 345)
            },
            {
                id: "floresta4",
                pitch: -18,
                yaw: 283,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta4', -18, 283)
            },
            {
                id: "floresta5",
                pitch: -13,
                yaw: 202,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta5', -13, 202)
            }
        ]
    },
    floresta4:{
        panorama: "https://i.imgur.com/RQ9OgkH.jpg",
        hotSpots:[
            {
                id: "floresta2",
                pitch: -7,
                yaw: 36,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta2', -7, 36)
            },
            {
                id: "floresta3",
                pitch: -11,
                yaw: -268,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta3', -11, -268)
            },
            {
                id: "floresta5",
                pitch: -8.7,
                yaw: -213,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta5', -8.7, -213)
            },
            {
                id: "floresta12",
                pitch: -20,
                yaw: 172,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta12', -20, 172)
            }
        ]
    },
    floresta5:{
        panorama: "https://i.imgur.com/CuSWQbC.jpg",
        hotSpots:[
            {
                id: "floresta6",
                pitch: -18,
                yaw: -223,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta6', -18, -223)
            },
            {
                id: "floresta3",
                pitch: -10,
                yaw: 24,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta3', -10, 24)
            },
            {
                id: "floresta4",
                pitch: -13,
                yaw: -29,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta4', -13, -29)
            },
            {
                id: "floresta12",
                pitch: -21,
                yaw: -75,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta12', -21, -75)
            }
        ]
    },
    floresta6:{
        panorama: "https://i.imgur.com/wKvQfyR.jpg",
        open: `client => {
            if(!client.get("dark-ambience")){
                let au      = client.AUDIO.playFile('/audio/ambience/dark-ambience.mp3')
                au.volume   = 1
                client.set("dark-ambience", au)
                console.log("[dark-ambience]")
            }
        }`,
        hotSpots:[
            {
                id: "floresta7",
                pitch: -7.5,
                yaw: 202,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta7', -7.5, 202)
            },
            {
                id: "floresta5",
                pitch: -8,
                yaw: 324,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta5', -8, 324)
            }
        ]
    },
    floresta7:{
        panorama: "https://i.imgur.com/35E0Tkc.jpg",
        open:`client => {
            if(!client.get("wolf")){
                let au      = client.AUDIO.playFile('/audio/ambience/wolf.mp3')
                au.volume   = .25
                client.set("wolf", au)
                console.log("[wolf]")
            }
        }`,
        hotSpots:[
            {
                id: "floresta6",
                pitch: -10,
                yaw: -345,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta6', -10, -345)
            },
            {
                id: "floresta8",
                pitch: -14,
                yaw: -255,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta8', -14, -255)
            }
            ,
            {
                id: "floresta9",
                pitch: -14,
                yaw: 265,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta9', -14, 265)
            }
        ]
    },
    floresta8:{
        panorama: "https://i.imgur.com/93rnGYD.jpg",
        hotSpots:[
            {
                id: "floresta7",
                pitch: -20,
                yaw: 298,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta7', -20, 298)
            },
            // {
            //     id: "floresta5",
            //     pitch: -8,
            //     yaw: 324,
            //     // cssClass: "hotspot-arrow",
            //     type:"info",
            //     html: "",
            //     style: "",
            //     clickHandlerFunc: fn.hotSpotFade('floresta5', -8, 324)
            // }
        ]
    },
    floresta9:{
        panorama: "https://i.imgur.com/mizJsSA.jpg",
        hotSpots:[
            {
                id: "floresta7",
                pitch: -15,
                yaw: -274,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta7', -15, -274)
            },
            {
                id: "floresta10",
                pitch: -14,
                yaw: 302,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta10', -14, 302)
            }
        ]
    },
    floresta10:{
        panorama: "https://i.imgur.com/a1Hz3Xv.jpg",
        hotSpots:[
            {
                id: "floresta9",
                pitch: -12,
                yaw: 118,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta9', -12, 118)
            },
            {
                id: "floresta11",
                pitch: -11,
                yaw: -313,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta11', -11, -313)
            }
        ]
    },
    floresta11:{
        panorama: "https://i.imgur.com/FYh4tIP.jpg",
        open:`client => {
            if(!client.get("midnight")){
                let au      = client.AUDIO.playFile('/audio/ambience/midnight.mp3')
                au.loop     = true
                au.volume   = .25
                client.set("midnight", au)
                console.log("[midnight]")
            }
        }`,
        hotSpots:[
            {
                id: "floresta10",
                pitch: -5,
                yaw: -143,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta10', -5, -143)
            },
            {
                id: "floresta12",
                pitch: -19,
                yaw: 35,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta12', -19, 35)
            }
        ]
    },
    floresta12:{
        panorama: "https://i.imgur.com/meerWI8.jpg",
        hotSpots:[
            {
                id: "floresta11",
                pitch: -8,
                yaw: 205,
                type:"info",
                clickHandlerFunc: fn.hotSpotFade('floresta11', -8, 205)
            },
            {
                id: "floresta5",
                pitch: -11,
                yaw: 104,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta5', -11, 104)
            },
            {
                id: "floresta4",
                pitch: -16,
                yaw: 15,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta4', -16, 15)
            },
            {
                id: "floresta3",
                pitch: -7,
                yaw: 54,
                // cssClass: "hotspot-arrow",
                type:"info",
                html: "",
                style: "",
                clickHandlerFunc: fn.hotSpotFade('floresta3', -7, 54)
            }
        ]
    }
}