module.exports = {
    panorama: "/textures/atual.jpg",
    hotSpots:[
        require('./hotspots/pc'),
        require('./hotspots/mapa'),
        require('./hotspots/caderno')
    ],
    open:`client => {
        $("#ui .dica img").attr("src", '/dicas/4.jpg')
    }`,
    
}