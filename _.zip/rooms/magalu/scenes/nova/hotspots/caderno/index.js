const fs    = require('fs')
let css     = fs.readFileSync(__dirname+'/css.css', 'utf8')
module.exports = {
    id: "caderno",
    pitch: -8,
    yaw: 150,
    type: "info",
    scale:true,
    cssClass:'hotspot-cliente',
    createTooltipArgs: '',
    createTooltipFunc: require('./tooltip').toString().replace("'%css%'", css),
    clickHandlerFunc:  require('./click').toString(),
}