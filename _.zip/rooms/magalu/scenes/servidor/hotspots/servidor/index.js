module.exports = {
    id: "servidor",
    pitch: 0,
    yaw: 14,
    type: "info",
    scale: true,
    text: "Servidor",
    clickHandlerFunc: '(event, client) => { client.openModal("servidor") }'
}