module.exports = {
    id: "circuitos",
    pitch: -5,
    yaw: -4,
    scale: true,
    type: "info",
    text: "Circuitos",
    clickHandlerFunc: '(event, client) => { client.openModal("circuito") }'
}