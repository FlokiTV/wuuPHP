module.exports = {
    // panorama: "https://i.imgur.com/qisaSHH.jpg",
    panorama: "/textures/servidor.jpg",
    haov:140,
    vaov:80,
    hfov:100,
    vOffset:0,
    minHfov: 90,
    maxHfov: 110,
    // 
    minYaw:-70,
    maxYaw:70,
    minPitch:-40,
    maxPitch:40,
    hotSpots:[
        require('./hotspots/manual'),
        require('./hotspots/servidor'),
        require('./hotspots/circuito'),
        
    ],
    open:`client => {
        client.setupModal("circuito")
        $("#ui .dica img").attr("src", '/dicas/6.jpg')
    }`,
}