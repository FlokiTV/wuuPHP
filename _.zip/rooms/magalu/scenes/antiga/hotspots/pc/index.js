module.exports = {
    id: "pc",
    pitch: -4.18,
    yaw: -148.06,
    type: "info",
    text: "Computador",
    clickHandlerFunc: '(event, client) => { client.openModal("email1") }'
}