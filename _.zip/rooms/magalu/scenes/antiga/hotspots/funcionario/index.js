module.exports = {
    id: "funcionario",
    pitch: -5,
    yaw: -130,
    type: "info",
    scale:true,
    // customClass:'pnlm-hotspot pnlm-sprite pnlm-info',
    createTooltipArgs: "<img src='/textures/funcionario.png' onload='$(this).parent().css(`margin-top`, `-${$(this).height()+10}px`)' style='width:100%'>",
    createTooltipFunc: `(hotSpotDiv, args) => {
        hotSpotDiv.classList.add('custom-tooltip');
        var span = document.createElement('span');
        var style = document.createElement('style');
        style.innerHTML = `+"`"+ `
            .custom-hotspot {
                height: 50px;
                width: 50px;
                background: #f00;
            }
            div.custom-tooltip span {
                visibility: hidden;
                position: absolute;
                border-radius: 3px;
                background-color: transparent;
                color: #000;
                text-align: center;
                padding: 5px 10px;
                cursor: default;
                width:140px;
            }
            div.custom-tooltip:hover span{
                visibility: visible;
            }`+"`"+`
        span.innerHTML = args;
        hotSpotDiv.appendChild(style);
        hotSpotDiv.appendChild(span);
        // span.style.width = span.scrollWidth - 20 + 'px';
        span.style.marginLeft = -(span.scrollWidth - hotSpotDiv.offsetWidth) / 2 + 'px';
        console.log($(span).find("img").height())
        // span.style.marginTop = -($(span).find("img").height + 30) + 'px';
    }`
}