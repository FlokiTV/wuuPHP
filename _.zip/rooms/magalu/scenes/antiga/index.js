module.exports = {
    panorama: "/textures/antiga.jpg",
    open:`client => {
        client.setupModal("prancheta")
        client.setupModal("circuito")
        let timer_click = setInterval(()=>{
            $(".pnlm-hotspot-base").off("click")
            $(".pnlm-hotspot-base").click(()=>{
                client.AUDIO.play("click")
            }).hover(()=>{
                client.set("hotspot.hover", true)
            }, ()=>{
                client.set("hotspot.hover", false)
            })
        },200)
        client.set("timer.click", timer_click)
    }`,
    hotSpots:[
        require('./hotspots/prancheta'),
        require('./hotspots/pc'),
        require('./hotspots/funcionario'),
        require('./hotspots/mapa')
    ]
}