module.exports = {
    apps : [
        {
          name: "magalu",
          script: "./index.js",
          watch: false,
          env: {
            "PORT": 80
          }
        }
    ]
  }