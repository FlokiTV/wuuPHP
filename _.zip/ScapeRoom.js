const colyseus    = require('colyseus');
const Room        = require('./rooms/magalu')

exports.Room = class extends colyseus.Room {
  maxClients  = 10
  Game        = {}
  onCreate (options) {
    this.Game = Room.init(this,options)
    this.Game.create(this, options)
    this.Game.listener(this)
    this.setPatchRate(1000/60)
    this.setSimulationInterval((deltaTime) => this.update(deltaTime));
  }

  onAuth (client, options, request){
    return this.Game.auth(this, client, options, request)
  }

  onJoin(client, options) {
    this.Game.join(this, client, options)
  }

  onLeave (client, consented) {
    this.Game.leave(this, client, consented)
  }

  onDispose(){
    this.Game.destroy(this)
  }
  
  update (deltaTime) {
    this.Game.tick(this, deltaTime)
  }
  // 
  // 
  // 
  setScene(scene){
    console.log("[CHANGING SCENE > SCAPEROM]")
    console.log(this.missionListTEMP)
    this.missionListTEMP = []
    console.log(this.missionListTEMP)
    this.state.scene = scene
    this.broadcast("scene.change", scene)
  }
  setSceneFade(scene){
    this.state.scene = scene.name
    this.broadcast("scene.fade", scene)
  }
  getPlayerClient(id){
    let clients = this.clients
    let ct      = false
    clients.forEach( client => {
      if(client.id == id) ct = client
    })
    return ct
  }
  getPlayerState(id){
    return this.state.players[id]
  }
  getStateByKey(key){
    if(this.state) 
        return this.state[key]
  }

}