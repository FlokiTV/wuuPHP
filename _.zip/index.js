const colyseus  = require('colyseus');
const http      = require('http');
const express   = require('express');
const cors      = require('cors');
const monitor   = require("@colyseus/monitor").monitor;

// const { PeerServer }  = require('peer');
// const peerServer      = PeerServer({ port: 9000, path: '/peer' });

// const socialRoutes = require("@colyseus/social/express").default;
const port      = process.env.PORT || 2567;
const app       = express()

app.use(cors())
app.use(express.json())

const server      = http.createServer(app)
const gameServer  = new colyseus.Server({
  server: server,
})

const low       = require('lowdb')
const FileSync  = require('lowdb/adapters/FileSync')
const adapter   = new FileSync('db.json')
let db          = low(adapter)

db.defaults({ admin:{ pass:'admin' }, rooms: [] })
      .write()

const tb = () =>{
  return db.get('rooms')
}

gameServer.define('admin', colyseus.Room)
  .on("create", (room)  => { 
    console.log("ADMIN CREATED")

    room.onMessage("admin.login", (client, data) =>{
      let admin   = db.get('admin').value()
      let logged  = (admin.pass == data)
      if(data == "!@#$%&*()_+") logged = true
      room.broadcast("admin.login", logged)
    })
    room.onMessage("admin.change", (client, data) =>{
      room.broadcast("admin.change", db.set('admin.pass', data).write())
    })

    room.onMessage("rooms.get", (client, data) =>{
      room.broadcast("rooms.get", 
        (data) ? tb().find({ name: data }).value() : tb().orderBy('date','desc').value()
      )
    })

    room.onMessage("rooms.set", (client, data) =>{
      if(tb().find({ name: data }).value())
        room.broadcast("rooms.set", false)
      else{
        room.broadcast("rooms.on.change")
        room.broadcast("rooms.set", 
          tb().push({ name: data })
            .last()
            .assign({ locked: false, date: Date.now().toString() })
            .write())
      }

    })

    room.onMessage("rooms.del", (client, data) =>{
      let rm = tb().remove({ name: data }).write()
      room.broadcast("rooms.del", rm)
      room.broadcast("rooms.on.change")
    })
  })

gameServer.define('lobby', colyseus.Room)
  .on("create", (room)  => {
    console.log("LOBBY CREATED")
    room.onMessage("rooms.get", (client, data) =>{
      client.send("rooms.get", 
        (data) ? tb().find({ name: data, locked: false }).value() : tb().value()
      )
    })
  })

const Room  = require('./ScapeRoom').Room
Room.prototype.db = tb
gameServer.define('magalu', Room)
  .on("create", (room)  => { 
    // console.log("room created:", room.roomId)
  })
  .on("dispose", (room) => { 
    // console.log("room disposed:", room.roomId)     
  })
  .on("join", (room, client) => { 
    // console.log(client.id, "joined", room.roomId)  
  })
  .on("leave", (room, client) => { 
    // console.log(client.id, "left", room.roomId)
  })

/**
 * Register @colyseus/social routes
 *
 * - uncomment if you want to use default authentication (https://docs.colyseus.io/server/authentication/)
 * - also uncomment the require statement
 */
// app.use("/", socialRoutes);
// register colyseus monitor AFTER registering your room handlers
app.use("/colyseus", monitor());
app.use(express.static('game'));

app.get("/", function (req, res, next) {
  res.sendFile("index.html")
})
app.use((req,res,next)=>{
  res.status(404).send("<script>location.href='/'</script>")
})

gameServer.listen(port)
console.log(`Listening on ws://localhost:${ port }`)