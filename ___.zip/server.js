const { PeerServer }    = require('peer')

module.exports = opts =>{
    const voip = PeerServer(opts)
    voip.on('connection', (client) => { 
        console.log('[peer on]', client.id)
    })
    voip.on('disconnect', (client) => { 
        console.log('[peer off]', client.id)
    });
}