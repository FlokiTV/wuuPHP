const dev = true
/** */
const cors      = require('cors')
const express   = require('express')
const app       = express()
const https     = require('https')
const http      = require('http')
const fs        = require('fs')
const SSL_PATH  = process.env.SSL_PATH || '/etc/letsencrypt/live/app.bh-escape.tk'
const port      = process.env.PORT || 3001
let pOpts = {
    port:  9000, 
    path: '/voip' 
}
if(!dev) pOpts.ssl = {
    key: fs.readFileSync(`${SSL_PATH}/privkey.pem`),
    cert: fs.readFileSync(`${SSL_PATH}/fullchain.pem`),
}
const voip      = require('./server')(pOpts)
const server    = (!dev) ? 
    https.createServer({
      key: pOpts.ssl.key,
      cert: pOpts.ssl.cert,
    }, app) 
    : http.createServer(app)

app.use(cors())
app.set('view engine', 'pug')
app.use(express.static('public'))

app.get('/', (req, res) => {
    res.sendFile("index.html")
//   res.redirect(`/${uuidV4()}`)
})


const io = require('socket.io')(server,{
    serveClient: false,
    cors: {
        origin: '*',
    }
})

var peerStream = false

io.on('connection', socket => {
    socket.on('join-room', (roomId, userId) => {
        console.log("[join-room] "+userId)
        socket.join(roomId)
        socket.to(roomId).broadcast.emit('user-connected', userId)
        socket.on('disconnect', () => {
            socket.to(roomId).broadcast.emit('user-disconnected', userId)
        })
        socket.on('get-stream', (userID) => {
            console.log("[get-stream] "+userID)
            io.to(roomId).emit('peer-stream', peerStream)
        })
        socket.on('set-stream', (streamID) => {
            peerStream = streamID
            console.log("[set-stream] "+peerStream)
            io.to(roomId).emit('peer-stream', peerStream)
        })
    })
})


server.listen(port)
console.log("listening")