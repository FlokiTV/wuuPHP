module.exports = {
    apps : [
        {
          name: "bhscape",
          script: "./index.js",
          watch: false,
          env: {
            "PORT": 443
          }
        }
    ]
  }