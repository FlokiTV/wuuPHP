const fn    = require('./func')
const front = require('./front')

module.exports = {
    default:{
        firstScene: "demo",
        type: "equirectangular",
        autoLoad: true,
        // showZoomCtrl: false,
        showFullscreenCtrl: false,
        showControls: true,
        // hotSpotDebug: true,
        // 
        friction:1,
        hfov: 120,
        minHfov: 65,
        maxHfov: 120,
    },
    scenes:{
        demo: require('./scenes/demo')
    },
    hud:{
        timer:{
            style:{},
            html:'',
            script:{}
        }
    },
    modals: require('./modals'),
    /**
     * Front Events
     */
    created:    front.created.toString(),
    init:       front.init.toString(),
    tick:       front.tick.toString(),
    click:      front.click.toString(),
    mousemove:  front.mousemove.toString()
}