module.exports = (room, client, consented) => {
    console.log(`Leave ${client.sessionId}`)
    delete room.state.players[client.sessionId]
    room.broadcast("leave", {
      client: client.sessionId
    })
}