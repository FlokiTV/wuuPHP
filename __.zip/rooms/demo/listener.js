const _ = require("lodash")

module.exports = (room) => {
    console.log(`Listener ${room.roomId}`)
    
    room.onMessage("peer.id", (client, data) =>{
        if(data)
            room.state.players[client.sessionId].peerID  = data
    })

    room.onMessage("mousepos", (client, data) =>{
        if(data)
            room.state.players[client.sessionId].pitch  = data.pitch
            room.state.players[client.sessionId].yaw    = data.yaw
    })

    room.onMessage("player.setup", (client, data) =>{
        room.state.players[client.sessionId].username   = data.username
        room.state.players[client.sessionId].color      = parseInt(data.color)
    })
    /**
     * SCENE
     */
    room.onMessage("scene.change", (client, data) =>{
        room.setScene(data)
    })
    room.onMessage("scene.fade", (client, data) =>{
        room.setSceneFade(data)
    })
    /**
     * READY MODAL
     */
    room.onMessage("player.ready.start", (client, data) =>{
        let started = _.find(room.getStateByKey("variables"), { id: 'player.ready' })
        if(started == undefined)
            room.state.variables.push( new room.Game.state.Variables('player.ready', '0') )
    })
    room.onMessage("player.ready.vote", (client, data) =>{
        let vote = _.find(room.getStateByKey("variables"), { id: 'player.ready' })
        if(vote != undefined){
            let value   = parseInt(vote.value) + 1
            vote.value  = value.toString()
            room.broadcast("player.ready.vote")
        }
    })
    /**
     * PRANCHETA MODAL
     */
    room.onMessage("prancheta.send", (client, data) =>{
        room.broadcast("prancheta.send", data, { except: client })
    })
    room.onMessage("drag.send", (client, data) =>{
        room.broadcast("drag.send", data, { except: client })
    })
    room.onMessage("drag.connect", (client, data) =>{
        room.broadcast("drag.connect", data)
        room.broadcast("audio.play","/audio/plug.mp3")
    })
    room.onMessage("mesa.send", (client, data) =>{
        room.broadcast("mesa.send", data, { except: client })
    })
    // netshoes
    room.onMessage("netshoes.connect", (client, data) =>{
        room.broadcast("netshoes.connect", data)
        room.broadcast("audio.play","/audio/muffled.mp3")
    })
    room.onMessage("code", (client, data) =>{
        let code = room.missionList[0].code
        if(data != code){
            client.send("audio.play","/audio/error.mp3")
            client.send("toast.fire", {
                title:'Código inválido',
                html:'',
                icon:'error',
            })
        }
        else{
            room.scene_end = code
        }
    })
}