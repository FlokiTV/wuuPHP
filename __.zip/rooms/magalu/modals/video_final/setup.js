module.exports = (client, el) => {
    el.find(".modal-content").css("width", "calc(100% - 20px)")
    el.find(".modal-content").css("height", "calc(100% - 20px)")
    el.find(".modal-background").css("background", "#000")
    
    $("#ui").hide()
    $("#modal-email_novo_10").css("z-index",99999)

    var _final = new vlitejs({
        selector: '#video-final',
        options: {
            autoplay: false,
            controls: false,
            nativeControlsForTouch: false
        },
        onReady: (player) => {
            var instance = player.getInstance()
            $(".v-poster").click()
            instance.addEventListener("onStateChange", e =>{
                el.find(".v-vlite").css("padding-top", el.find(".modal-content").height())
                switch(e.data) {
                    case 0:
                        console.log('video ended');
                        _final.destroy()
                        client.closeModal(id)
                        break;
                    case 1:
                        console.log('video playing from '+ instance.getCurrentTime());
                        break;
                    case 2:
                        player.play()
                        console.log('video paused at '+ instance.getCurrentTime());
                }
            })
        }
    });

    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
        _final.destroy()
        // client.openModal("ready")
    })
    .remove() //REMOVE CLOSE BUTTON
}