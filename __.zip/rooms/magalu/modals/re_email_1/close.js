module.exports = (client, el) => {
    // client.openModal("email2")
    client.AUDIO.playFile("/audio/email.mp3")
}
