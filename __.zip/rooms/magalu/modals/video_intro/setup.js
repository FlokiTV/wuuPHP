module.exports = (client, el) => {
    el.find(".modal-content").css("width", "calc(100% - 20px)")
    el.find(".modal-content").css("height", "calc(100% - 20px)")
    el.find(".modal-background").css("background", "#000")
    var _introPlayer = new vlitejs({
        selector: '#video-intro',
        onReady: (player) => {
            var instance = player.getInstance()
            $(".v-poster").click()
            el.find(".v-vlite").css("padding-top", el.find(".modal-content").height())
            instance.addEventListener("onStateChange", e =>{
                switch(e.data) {
                    case 0:
                        console.log('video ended');
                        _introPlayer.destroy()
                        client.closeModal(id)
                        break;
                    case 1:
                        console.log('video playing from '+ instance.getCurrentTime());
                        break;
                    case 2:
                        console.log('video paused at '+ instance.getCurrentTime());
                }
            })
        }
    });

    el.find(".modal-close").click( ev =>{
        client.closeModal(id)
        _introPlayer.destroy()
        // client.openModal("ready")
    })
    .remove() //REMOVE CLOSE BUTTON
}