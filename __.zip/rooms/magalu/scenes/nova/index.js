module.exports = {
    panorama: "/textures/atual.jpg",
    hotSpots:[
        require('./hotspots/pc'),
        require('./hotspots/mapa'),
        require('./hotspots/caderno')
    ]
}