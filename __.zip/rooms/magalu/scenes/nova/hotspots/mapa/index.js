module.exports = {
    id: "mapa2",
    pitch: 2.80,
    yaw: -78,
    type: "info",
    // text: "Mapa",
    clickHandlerFunc: '(event, client) => { client.openModal("mapa2") }'
}