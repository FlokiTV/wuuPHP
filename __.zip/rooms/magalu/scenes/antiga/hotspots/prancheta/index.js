module.exports = {
    id: "prancheta",
    pitch: -41,
    yaw: -219,
    type: "info",
    text: "Prancheta",
    clickHandlerFunc: '(event, client) => { client.openModal("prancheta") }'
}